// pages/AdminPage.tsx
import React from 'react';

const AdminPage: React.FC = () => {
  // Здесь вы можете использовать состояние и эффекты для управления данными администратора
  return (
    <div>
      <h1>Страница администратора</h1>
      {/* Здесь будет ваша форма для добавления, изменения и удаления информации о студентах */}
    </div>
  );
};

export default AdminPage;
